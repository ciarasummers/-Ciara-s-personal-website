# Jessica — Personal Website

A feminine, editorial, personal website built with plain HTML, CSS and JavaScript.

## Files
- `index.html`
- `style.css`
- `script.js`
- `assets/jessica-photo.png`
- `assets/favicon.svg`

## Open it
Double-click `index.html`. No installation is needed.

## GitHub Pages
Create a repository named `<your-github-username>.github.io`, upload these files directly into the repository root, then go to **Settings → Pages → Deploy from a branch → main → / (root) → Save**.

Make sure `index.html` is directly in the root. Your site will be available at `https://<your-github-username>.github.io/`.

## Update
Edit `index.html` for text/content and `style.css` for design. Replace `assets/jessica-photo.png` to change the main photo.
